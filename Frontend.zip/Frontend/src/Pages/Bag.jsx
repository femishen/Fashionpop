import React, { useEffect, useState, useContext } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { CartContext } from '../context/CartContext';
import './Bag.css';

const Bag = () => {
  const [items, setItems] = useState([]);
  const navigate = useNavigate();
  const { fetchBagCount } = useContext(CartContext); // ✅ fix here

  useEffect(() => {
    fetchBagItems();
  }, []);

  const fetchBagItems = async () => {
    try {
      const res = await axios.get('http://localhost:4000/api/bag', { withCredentials: true });
      setItems(res.data);
    } catch (err) {
      if (err.response?.status === 401) navigate('/login');
      else console.error('Failed to load bag items:', err);
    }
  };

  const updateQuantity = (index, delta) => {
    const updatedItems = [...items];
    const item = updatedItems[index];
    if (item.quantity + delta >= 1) {
      item.quantity += delta;
      setItems(updatedItems);
    }
  };

  const handleSaveForLater = async (item) => {
    try {
      const wishlistItem = {
        name: item.name,
        image: item.image,
        dis_price: item.dis_price,
        price: item.price,
        description: item.description
      };

      await axios.post('http://localhost:4000/api/wishlist', wishlistItem, { withCredentials: true });
      await axios.delete(`http://localhost:4000/api/bag/${item.id}`, { withCredentials: true });

      setItems(prev => prev.filter(i => i.id !== item.id));
      await fetchBagCount(); // ✅ badge updates here
      alert("Moved to wishlist!");
    } catch (err) {
      console.error("Save for later failed:", err);
      alert("Something went wrong");
    }
  };

  const handleRemove = async (id) => {
    try {
      await axios.delete(`http://localhost:4000/api/bag/${id}`, { withCredentials: true });
      fetchBagItems();
      await fetchBagCount(); // ✅ optional: keep badge synced
    } catch (err) {
      console.error('Remove failed:', err);
    }
  };

  const calculateTotal = () => {
    return items.reduce((total, item) => total + item.dis_price * item.quantity, 0);
  };

  return (
    <div className="bag-container">
      <h2>Add To Cart</h2>
      {items.length === 0 ? (
        <h2 className="empty-msg">Your bag is empty.</h2>
      ) : (
        <>
          {items.map((item, index) => (
            <div className="bag-item" key={item.id}>
              <img src={item.image} alt={item.name} className="item-img" />
              <div className="item-details">
                <h3>{item.name}</h3>
                <p className="description">{item.description}</p>
                <div className="price-section">
                  <span className="price">₹{item.dis_price * item.quantity}</span>
                  <del className="original">₹{item.price * item.quantity}</del>
                  <span className="discount">
                    {Math.round(((item.price - item.dis_price) / item.price) * 100)}% Off
                  </span>
                </div>
                <div className="quantity-controls">
                  <button onClick={() => updateQuantity(index, -1)}>-</button>
                  <span>{item.quantity}</span>
                  <button onClick={() => updateQuantity(index, 1)}>+</button>
                </div>
                <div className="action-buttons">
                  <button className="save-btn" onClick={() => handleSaveForLater(item)}>SAVE FOR LATER</button>
                  <button className="remove-btn" onClick={() => handleRemove(item.id)}>REMOVE</button>
                </div>
              </div>
            </div>
          ))}
          <div className="place-order-bar">
            <span>Total: ₹{calculateTotal()}</span>
            <button className="place-order-btn" onClick={() => navigate('/checkout')}>
              PLACE ORDER
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default Bag;
