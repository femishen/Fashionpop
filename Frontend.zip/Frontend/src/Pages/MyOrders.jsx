import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './MyOrders.css';

function MyOrders() {
  const [orders, setOrders] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    axios.get('http://localhost:4000/api/orders/my', { withCredentials: true })
      .then(res => setOrders(res.data))
      .catch(err => console.error("Failed to fetch orders:", err));
  }, []);

  return (
    <div className="my-orders-container">
      <h2>📦 My Orders</h2>

      {orders.length === 0 ? (
        <p className="no-orders">You haven’t placed any orders yet.</p>
      ) : (
        orders.map(order => (
          <div className="order-card" key={order.id}>
            <p><strong>Date:</strong> {new Date(order.created_at).toLocaleString()}</p>
            <p><strong>Name:</strong> {order.customerName}</p>
            <p><strong>Phone:</strong> {order.phone}</p>
            <p><strong>Address:</strong> {order.address}</p>
            <p><strong>Payment:</strong> {order.payment_mode}</p>
            <p><strong>Total Price:</strong> ₹{Number(order.total_price || 0).toFixed(2)}</p>

            <div className="order-items">
              {JSON.parse(order.items).map((item, index) => (
                <div className="order-item" key={index}>
                  <img src={item.image} alt={item.name} className="order-img" />
                  <div className="item-info">
                    <h6>{item.name}</h6>
                    <p>Qty: {item.quantity}</p>
                    <span className="status-label">Status: {order.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))
      )}

    </div>
  );
}

export default MyOrders;
