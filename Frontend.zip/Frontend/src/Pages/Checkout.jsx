import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useLocation } from 'react-router-dom';
import './Checkout.css';

function Checkout() {
  const location = useLocation();
  const buyNowItem = location.state?.buyNowItem;

  const [items, setItems] = useState([]);
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [paymentMode, setPaymentMode] = useState('Cash on Delivery');
  const [total, setTotal] = useState(0);
 
  useEffect(() => {
    if (buyNowItem) {
      // Set single product for Buy Now
      setItems([buyNowItem]);
      setTotal(buyNowItem.dis_price * buyNowItem.quantity);
    } else {
      // Load full cart
      axios.get('http://localhost:4000/api/bag', { withCredentials: true })
        .then(res => {
          setItems(res.data);
          const totalAmount = res.data.reduce((sum, item) => sum + item.dis_price * item.quantity, 0);
          setTotal(totalAmount);
        })
        .catch(err => console.error("Failed to load cart:", err));
    }
  }, []);

  const handleOrder = async (e) => {
    e.preventDefault();

    const order = {
      customerName: name,
      address,
      phone,
      payment_mode: paymentMode,
      items
    };

    try {
      await axios.post('http://localhost:4000/api/orders', order, {
        withCredentials: true
      });

      const toastEl = document.getElementById('orderToast');
      const toast = new window.bootstrap.Toast(toastEl);
      toast.show();

      setTimeout(() => {
        window.location.href = '/';
      }, 2500);

    } catch (err) {
      console.error("Order failed:", err);
      alert("Something went wrong!");
    }
  };

  return (
    <div className="checkout-container">
      <h2>Checkout</h2>

      <form onSubmit={handleOrder} className="checkout-form">
        <input
          value={name}
          onChange={e => setName(e.target.value)}
          placeholder="Full Name"
          required
        />
        <textarea
          value={address}
          onChange={e => setAddress(e.target.value)}
          placeholder="Address"
          required
        />
        <input
          value={phone}
          onChange={e => setPhone(e.target.value)}
          placeholder="Phone Number"
          required
        />

        <select value={paymentMode} onChange={e => setPaymentMode(e.target.value)} required>
          <option value="Cash on Delivery">Cash on Delivery</option>
          <option value="UPI">UPI</option>
          <option value="Credit/Debit Card">Credit/Debit Card</option>
          <option value="Net Banking">Net Banking</option>
        </select>

        <h3>Order Summary</h3>
        <ul className="order-summary">
          {items.map(item => (
            <li key={item.id}>
              <img src={item.image} alt={item.name} />
              <span>{item.name} × {item.quantity}</span>
              <span>₹{item.dis_price * item.quantity}</span>
            </li>
          ))}
        </ul>

        <h4 className="mt-3">Total: ₹{total.toFixed(2)}</h4>

        <button type="submit" className="place-order-btn">Place Order</button>
      </form>

      <div className="toast-container position-fixed bottom-0 end-0 p-3">
        <div className="toast align-items-center text-white bg-success border-0" id="orderToast" role="alert">
          <div className="d-flex">
            <div className="toast-body">
              ✅ Order placed successfully!
            </div>
            <button type="button" className="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Checkout;
