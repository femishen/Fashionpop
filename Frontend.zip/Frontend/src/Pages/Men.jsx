// src/pages/Tshirt.jsx

import React, { useEffect, useState } from 'react';
import Product from '../components/Product';
import axios from 'axios';

function Men() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:4000/api/products')
      .then(res => {
        console.log(res.data)

        const all = res.data;
       
        const men = all.filter(p => p.category_id === 2);
        setProducts(men);
      })
      .catch(err => console.error('Error fetching products:', err));
  }, []);

  return (
    <>
      <h1>Men Collections</h1>
      <div className="products" style={{ display: 'flex', gap: '40px', flexWrap: 'wrap', marginLeft:'70px' }}>
        {products.map((p, index) => (
          <Product
            key={index}
            name={p.name}
            image={`http://localhost:4000/Public/Images/${p.image_url}`}
            dis_price={p.price - (p.price * p.discount / 100)}
            price={p.price}
            description={p.description}
          />
        ))}
      </div>
    </>
  );
}

export default Men;
