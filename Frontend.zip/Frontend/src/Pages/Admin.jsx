// src/pages/Admin.jsx
import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import './Admin.css';

const Admin = () => {
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [productName, setProductName] = useState('');
  const [description, setDescription] = useState('');
  const [image, setImage] = useState(null);
  const [price, setPrice] = useState('');
  const [discount, setDiscount] = useState('');
  const [products, setProducts] = useState([]);
  const [editId, setEditId] = useState(null);
  const formRef = useRef(null);

  useEffect(() => {
    fetchCategories();
    fetchProducts();
  }, []);

  const fetchCategories = async () => {
    try {
      const res = await axios.get('http://localhost:4000/api/categories');
      setCategories(res.data);
    } catch (err) {
      alert("Failed to load categories.");
    }
  };

  const fetchProducts = async () => {
    try {
      const res = await axios.get('http://localhost:4000/api/products');
      setProducts(res.data);
    } catch (err) {
      alert("Failed to load products.");
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append('category_id', selectedCategory);
    formData.append('productName', productName);
    formData.append('description', description);
    formData.append('image', image);
    formData.append('price', price);
    formData.append('discount', discount);

    try {
      if (editId) {
        await axios.put(`http://localhost:4000/api/products/${editId}`, formData);
        alert('✅ Product updated successfully!');
      } else {
        await axios.post('http://localhost:4000/api/products', formData);
        alert('✅ Product added successfully!');
      }

      resetForm();
      fetchProducts();
    } catch (err) {
      console.error('Error saving product:', err);
      alert('❌ Error saving product. Please try again.');
    }
  };

  const handleEdit = (product) => {
    setEditId(product.id);
    setSelectedCategory(product.category_id);
    setProductName(product.name);
    setDescription(product.description);
    setPrice(product.price);
    setDiscount(product.discount);
    setImage(null);

    // Scroll to form
    formRef.current.scrollIntoView({ behavior: 'smooth' });
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this product?')) {
      try {
        await axios.delete(`http://localhost:4000/api/products/${id}`);
        alert('🗑️ Product deleted successfully!');
        fetchProducts();
      } catch (err) {
        alert('❌ Error deleting product.');
      }
    }
  };

  const resetForm = () => {
    setEditId(null);
    setSelectedCategory('');
    setProductName('');
    setDescription('');
    setImage(null);
    setPrice('');
    setDiscount('');
  };

  return (
    <div className="admin-container">
      <h2 ref={formRef}>{editId ? 'Edit Product' : 'Add New Product'}</h2>

      <form onSubmit={handleSubmit} className="product-form">
        <div className="form-group">
          <label>Category</label>
          <select value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)} required>
            <option value="">Select a Category</option>
            {categories.map((cat) => (
              <option key={cat.id} value={cat.id}>{cat.name}</option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label>Product Name</label>
          <input type="text" value={productName} onChange={(e) => setProductName(e.target.value)} required />
        </div>

        <div className="form-group">
          <label>Description</label>
          <textarea value={description} onChange={(e) => setDescription(e.target.value)} required />
        </div>

        <div className="form-group">
          <label>Image</label>
          <input type="file" onChange={(e) => setImage(e.target.files[0])} />
        </div>

        <div className="form-group">
          <label>Price</label>
          <input type="number" value={price} onChange={(e) => setPrice(e.target.value)} required />
        </div>

        <div className="form-group">
          <label>Discount (%)</label>
          <input type="number" value={discount} onChange={(e) => setDiscount(e.target.value)} />
        </div>

        <div className="form-buttons">
          <button type="submit">{editId ? 'Update' : 'Add'} Product</button>
          {editId && <button type="button" onClick={resetForm}>Cancel Edit</button>}
        </div>
      </form>

      <hr />
      <h3>All Products</h3>

      <table className="product-table">
        <thead>
          <tr>
            <th>S.No</th>
            <th>Image</th>
            <th>Name</th>
            <th>Description</th>
            <th>Price</th>
            <th>Discount</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {products.map((product, index) => (
            <tr key={product.id}>
              <td>{index + 1}</td>
              <td>
                {product.image_url && (
                  <img
                    src={`http://localhost:4000/Public/Images/${product.image_url}`}
                    alt="product"
                    className="product-img"
                  />
                )}
              </td>
              <td>{product.name}</td>
              <td>{product.description}</td>
              <td>₹{product.price}</td>
              <td>{product.discount ? `${product.discount}%` : '-'}</td>
              <td>
                <button onClick={() => handleEdit(product)} className="edit-btn">Edit</button>
                <button onClick={() => handleDelete(product.id)} className="delete-btn">Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Admin;
