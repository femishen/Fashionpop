import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Wishlist.css';
import { CartContext } from '../context/CartContext';

function Wishlist() {
  const [wishlistItems, setWishlistItems] = useState([]);
  const navigate = useNavigate();
  const { fetchBagCount } = useContext(CartContext);

  useEffect(() => {
    fetchWishlist();
  }, []);

  const fetchWishlist = async () => {
    try {
      const res = await axios.get('http://localhost:4000/api/wishlist', { withCredentials: true });
      setWishlistItems(res.data);
    } catch (err) {
      if (err.response?.status === 401) navigate('/login');
      else console.error("Error fetching wishlist:", err);
    }
  };

  const removeFromWishlist = async (itemId) => {
    try {
      await axios.delete(`http://localhost:4000/api/wishlist/${itemId}`, { withCredentials: true });
      setWishlistItems((prev) => prev.filter((item) => item.id !== itemId));
      alert("Item removed from wishlist");
    } catch (err) {
      console.error("Error removing item:", err);
    }
  };

const handleAddToCart = async (item) => {
  try {
    await axios.post('http://localhost:4000/api/bag', { 
      name: item.name,
      image: item.image,
      dis_price: item.dis_price,
      price: item.price,
      description: item.description,
      quantity: 1
    }, { withCredentials: true });

    await fetchBagCount(); // 🔄 Update bag icon

    // ✅ Optionally remove from wishlist after adding to bag
    await axios.delete(`http://localhost:4000/api/wishlist/${item.id}`, { withCredentials: true });
    setWishlistItems(prev => prev.filter(w => w.id !== item.id));
  } catch (err) {
    console.error("Add to bag failed:", err);
  }
};


  return (
    <div className="likedItems-container">
      <h1>Wishlist</h1>
      {wishlistItems.length === 0 ? (
        <p className="cart-empty-message">Your wishlist is empty</p>
      ) : (
        <div className="likedItems-items" style={{ display: 'flex', gap: '15px', flexWrap: 'wrap' }}>
          {wishlistItems.map((item) => (
            <div key={item.id} className="likedItems-card" style={{ border: '1px solid #ccc', padding: '10px', width: '300px' }}>
              <img src={item.image} alt={item.name}/>
              <h4>{item.name}</h4>
              <p style={{ color: 'green' }}>₹{item.dis_price}</p>
              <p>{item.description}</p>

   <button
  className="add-btn"
  onClick={() => handleAddToCart(item)}
>
  Add to Cart
</button>

<button
  className="remove-btn"
  onClick={() => removeFromWishlist(item.id)}
>
  Remove
</button>


            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Wishlist;
