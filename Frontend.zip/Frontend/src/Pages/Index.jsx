import React from 'react'
import Navbar from '../components/Navbar'
import Carousel from '../Components/Carousel'
import Category from '../Components/Category'
import TrendingNow from '../Components/TrendingNow'
import Footer from '../components/Footer'

function Index() {
  return (
    <>
    <Navbar />
    <Carousel/>
    <Category/>
    <TrendingNow />
    <Footer />

    </>
  )
}

export default Index;
