import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import './Login.css';

export default function Login() {
  const location = useLocation();
  const navigate = useNavigate();
  const isLogin = location.pathname === '/login';

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  useEffect(() => {
    setUsername('');
    setPassword('');
  }, [isLogin]);

const handleSubmit = async (e) => {
  e.preventDefault();
  const endpoint = isLogin ? '/api/users/login' : '/api/users/register';

  try {
    const res = await axios.post(`http://localhost:4000${endpoint}`, {
      username,
      password
    }, {
      withCredentials: true
    });

    alert(res.data.message);

    if (isLogin) {
      localStorage.setItem('username', username);
      navigate('/');
    } else {
      setTimeout(() => {
        navigate('/login'); // ✅ just go to login page
      }, 500);
    }
  } catch (err) {
    console.error("Submission error:", err);
    alert(err.response?.data?.error || "Something went wrong");
  }
};


  return (
    <div className="login-container">
      <div className="login-box">
        <h2>Welcome</h2>
        <div className="tabs">
          <Link to="/login" className={isLogin ? 'active' : ''}>LOGIN</Link>
          <Link to="/register" className={!isLogin ? 'active' : ''}>REGISTER</Link>
        </div>

        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="User ID"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <button type="submit">{isLogin ? 'Sign In' : 'Register'}</button>
        </form>
      </div>
    </div>
  );
}
