import { BrowserRouter, Routes, Route } from "react-router-dom";
import 'bootstrap-icons/font/bootstrap-icons.css';
import './App.css'
import Women from './Pages/Women'
import Men from './Pages/Men'
import Index from './Pages/Index'
import Kids from "./Pages/Kids"
import Home from "./Pages/Home"
import Jewellery from "./Pages/Jewellery"
import Navbar from "./components/Navbar"
import Footer from "./components/Footer";
import Admin from "./pages/Admin"
import AdminLogin from "./pages/AdminLogin";
import Wishlist from "./Pages/Wishlist";
import Bag from "./Pages/Bag";
import Login from "./Pages/Login";
import Checkout from "./Pages/Checkout";
import MyOrders from "./Pages/MyOrders"
import HandBag from "./Pages/HandBag";
import FootWear from "./Pages/FootWear";

function App(){
  return (
    <>
       <BrowserRouter>
      <Routes>
        <Route path="/" element={<Index />}/>
        <Route path="/Women" element={<><Navbar/><Women/><Footer/></>} />
        <Route path="/Men" element={<><Navbar/><Men /><Footer/></>} />
        <Route path="/Kids" element={<><Navbar/><Kids /><Footer/></>} />
        <Route path="/Home" element={<><Navbar/><Home /><Footer/></>} />
        <Route path="/Jewellery" element={<><Navbar/><Jewellery/><Footer/></>} />
        <Route path="/Admin" element={<><Navbar/><Admin /><Footer/></>} />
        <Route path="/AdminLogin" element={<><Navbar/><AdminLogin/></>}/>
        <Route path="/Wishlist" element={<><Navbar/><Wishlist /><Footer/></>} />
        <Route path="/Bag" element={<><Navbar/><Bag/><Footer/></>} />
        <Route path="/login" element={<><Navbar/><Login/></>}/>
        <Route path="/register" element={<><Navbar/><Login/></>} />
        <Route path="/Checkout" element={<><Navbar/><Checkout /></>} />
        <Route path="/MyOrders" element={<><Navbar/><MyOrders /></>} />
        <Route path="/HandBag" element={<><Navbar/><HandBag /><Footer/></>} />
        <Route path="/FootWear" element={<><Navbar/><FootWear /><Footer/></>} />
      </Routes>
    </BrowserRouter>
        </> 
  )
}

export default App
