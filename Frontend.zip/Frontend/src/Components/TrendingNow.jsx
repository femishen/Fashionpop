// src/components/TrendingNow.jsx
import React from 'react';
import './TrendingNow.css';
import { useNavigate } from 'react-router-dom';


const trendingItems = [
  {
    title: 'Drops & Danglers',
    images: [
      '/images/jewel1.avif',
      '/images/jewel2.avif',
      '/images/jewel3.avif',
      '/images/jewel4.avif'
    ],
    path: '/Jewellery'
  },
  {
    title: 'Bags',
    images: [
      '/images/bag1.avif',
      '/images/bag2.avif',
      '/images/bag3.avif',
      '/images/bag4.avif'
    ],
    path: '/HandBag'
  },
  {
    title: 'Home Goods',
    images: [
      '/images/home1.avif',
      '/images/home2.avif',
      '/images/home3.avif',
      '/images/home4.avif'
    ],
    path: '/Home'
  },
  {
    title: 'Iconic Sneakers',
    images: [
      '/images/shoe1.avif',
      '/images/shoe2.avif',
      '/images/shoe3.avif',
      '/images/shoe4.avif'
    ],
    path: '/FootWear'
  }
];

const TrendingNow = () => {
  const navigate = useNavigate();

  return (
    <div className="trending-container">
      <h2>Trending Now</h2>
      <div className="trending-grid">
        {trendingItems.map((item, index) => (
          <div className="trend-card" key={index}>
            <div className="trend-images">
              {item.images.map((img, i) => (
                <img key={i} src={img} alt="trending" />
              ))}
            </div>
            <h4>{item.title}</h4>
            <button onClick={() => navigate(item.path)}>Shop Now →</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TrendingNow;
