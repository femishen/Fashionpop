import React, { useEffect, useState, useContext } from 'react';
import img from '/namelogo.svg';
import { Outlet, Link, useNavigate } from "react-router-dom";
import axios from 'axios';
import { CartContext } from '../context/CartContext';

function Navbar() {
  const { bagCount, fetchBagCount } = useContext(CartContext);
  const [username, setUsername] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    fetchBagCount();
    const name = localStorage.getItem('username');
    if (name) {
      setUsername(name);
    } else {
      axios.get('http://localhost:4000/api/users/me', { withCredentials: true })
        .then(res => setUsername(res.data.username))
        .catch(() => setUsername(''));
    }
  }, []);

  const handleLogout = async () => {
    await axios.post('http://localhost:4000/api/users/logout', {}, { withCredentials: true });
    localStorage.removeItem('username');
    setUsername('');
    window.location.reload();
  };

  return (
    <>
      <nav className="navbar navbar-expand-lg bg-white shadow-sm px-4 fixed-top">
        <div className="container-fluid">
          <Link to="/" className="navbar-brand">
            <img src={img} alt="logo" height="35" />
          </Link>

          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
            <span className="navbar-toggler-icon"></span>
          </button>

          <div className="collapse navbar-collapse" id="navbarContent">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item"><Link to="/Women" className="nav-link">Women</Link></li>
              <li className="nav-item"><Link to="/Men" className="nav-link">Men</Link></li>
              <li className="nav-item"><Link to="/Kids" className="nav-link">Kids</Link></li>
              <li className="nav-item"><Link to="/Jewellery" className="nav-link">Jewellery</Link></li>
            </ul>

            <form className="d-flex search-form me-4" role="search">
              <input className="form-control" type="search" placeholder="Search for products, styles, brands" />
            </form>

            <div className="nav-icons d-flex align-items-center gap-4">

              {username ? (
                <div className="dropdown">
                  <span className="text-dark icon-link dropdown-toggle" data-bs-toggle="dropdown" role="button">
                    <i className="bi bi-person fs-5"></i>
                    <div><small>{username}</small></div>
                  </span>
                  <ul className="dropdown-menu dropdown-menu-end">
                    <li><Link className="dropdown-item" to="/MyOrders">My Orders</Link></li>
                    <li><button className="dropdown-item" onClick={handleLogout}>Logout</button></li>
                  </ul>
                </div>
              ) : (
                <Link to="/login" className="text-center text-dark icon-link">
                  <i className="bi bi-person fs-5"></i>
                  <div><small>Account</small></div>
                </Link>
              )}

              <Link to="/Wishlist" className="text-center text-dark icon-link">
                <i className="bi bi-heart fs-5"></i>
                <div><small>Wishlist</small></div>
              </Link>

              <Link to="/Bag" className="text-center text-dark icon-link position-relative">
                <i className="bi bi-bag fs-5"></i>
                {bagCount > 0 && (
                  <span className="badge bg-danger rounded-pill cart-count-badge position-absolute top-0 start-100 translate-middle">
                    {bagCount}
                  </span>
                )}
                <div><small>Cart</small></div>
              </Link>

              {!username && (
                <Link to="/AdminLogin" className="text-center text-dark icon-link">
                  <i className="bi bi-shield-lock fs-5"></i>
                  <div><small>Admin</small></div>
                </Link>
              )}
            </div>
          </div>
        </div>
      </nav>

      <Outlet />
    </>
  );
}

export default Navbar;
