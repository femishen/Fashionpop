import React, { useState, useEffect, useContext } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { CartContext } from "../context/CartContext";
import "./Product.css";

function Product({ image, name, dis_price, price, description }) {
  const [added, setAdded] = useState(false);
  const [liked, setLiked] = useState(false);
  const [wishlistId, setWishlistId] = useState(null);

  const navigate = useNavigate();
  const { fetchBagCount } = useContext(CartContext);

  /* ===========================
     AUTH CHECK
  ============================ */
  const tokenCheck = async () => {
    try {
      await axios.get("http://localhost:4000/api/users/me", {
        withCredentials: true
      });
      return true;
    } catch {
      alert("Please login to continue");
      return false;
    }
  };

  /* ===========================
     CHECK CART & WISHLIST STATUS
  ============================ */
  useEffect(() => {
    const loadStatus = async () => {
      try {
        const [bagRes, wishRes] = await Promise.all([
          axios.get("http://localhost:4000/api/bag", { withCredentials: true }),
          axios.get("http://localhost:4000/api/wishlist", { withCredentials: true })
        ]);

        // Check cart
        if (bagRes.data.some(item => item.name === name)) {
          setAdded(true);
        }

        // Check wishlist
        const wishItem = wishRes.data.find(item => item.name === name);
        if (wishItem) {
          setLiked(true);
          setWishlistId(wishItem._id || wishItem.id);
        }
      } catch (err) {
        console.log("User not logged in or error loading data");
      }
    };

    loadStatus();
  }, [name]);

  /* ===========================
     ADD TO CART
  ============================ */
  const handleAddToCart = async () => {
    const ok = await tokenCheck();
    if (!ok || added) return;

    const product = {
      name,
      image,
      dis_price,
      price,
      description,
      quantity: 1
    };

    try {
      await axios.post("http://localhost:4000/api/bag", product, {
        withCredentials: true
      });
      setAdded(true);
      fetchBagCount();
    } catch (err) {
      console.error("Add to cart failed:", err);
    }
  };

  /* ===========================
     BUY NOW
  ============================ */
  const handleBuyNow = async () => {
    const ok = await tokenCheck();
    if (!ok) return;

    const product = {
      name,
      image,
      dis_price,
      price,
      description,
      quantity: 1
    };

    navigate("/checkout", { state: { buyNowItem: product } });
  };

  /* ===========================
     WISHLIST TOGGLE
  ============================ */
  const handleToggleLike = async () => {
    const ok = await tokenCheck();
    if (!ok) return;

    try {
      if (liked) {
        await axios.delete(
          `http://localhost:4000/api/wishlist/${wishlistId}`,
          { withCredentials: true }
        );
        setLiked(false);
        setWishlistId(null);
      } else {
        const product = { name, image, dis_price, price, description };

        const res = await axios.post(
          "http://localhost:4000/api/wishlist",
          product,
          { withCredentials: true }
        );

        setLiked(true);
        setWishlistId(res.data?._id || null);
      }
    } catch (err) {
      console.error("Wishlist operation failed:", err);
    }
  };

  /* ===========================
     DISCOUNT CALCULATION
  ============================ */
  const discount =
    price && dis_price
      ? Math.round(((price - dis_price) / price) * 100)
      : 0;

  /* ===========================
     UI
  ============================ */
  return (
    <div className="product-card">
      <div
        className="wishlist-icon"
        onClick={handleToggleLike}
        style={{ color: liked ? "red" : "black", cursor: "pointer" }}
      >
        {liked ? "♥" : "♡"}
      </div>

      <img src={image} alt={name} />

      <h3>{name}</h3>
      <p>{description}</p>

      <p className="price">
        ₹{dis_price} <del>₹{price}</del>
        {discount > 0 && (
          <span className="discount">{discount}% off</span>
        )}
      </p>

      <button
        onClick={handleAddToCart}
        className="add-btn"
        disabled={added}
      >
        {added ? "Item Added" : "Add to Cart"}
      </button>

      <button onClick={handleBuyNow} className="buy-btn">
        Buy Now
      </button>
    </div>
  );
}

export default Product;
