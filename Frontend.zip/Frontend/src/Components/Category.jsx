// src/components/Categories.jsx
import React from 'react';
import { useNavigate } from 'react-router-dom';

const categories = [
  { name: "Women", image: "/images/women.avif" },
  { name: "Men", image: "/images/men.avif" },
  { name: "Kids", image: "/images/kid.avif" },
  { name: "Jewellery", image: "/images/jewellery.avif" },
];

const Category = () => {
  const navigate = useNavigate();

  const handleClick = (name) => {
    navigate(`/${name.toLowerCase()}`);
  };

  return (
    <div className="categories-container">
      {categories.map((cat, index) => (
        <div
          className="category-card"
          key={index}
          onClick={() => handleClick(cat.name)}
        >
          <img src={cat.image} alt={cat.name} />
          <p>{cat.name}</p>
        </div>
      ))}
    </div>
  );
};

export default Category;
