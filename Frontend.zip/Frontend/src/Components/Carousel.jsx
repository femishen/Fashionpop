import React from 'react'
import img1 from '/src/assets/images/img1.webp'

function Carousel() {
  return (
    <>
    <div className='carousel'>
    <img src={img1} className="img-fluid" alt="..."  />
    </div>
    </>
  )
}

export default Carousel