// src/context/CartContext.js
import { createContext, useState, useEffect } from 'react';
import axios from 'axios';

export const CartContext = createContext();

export const CartProvider = ({ children }) => {
  const [bagCount, setBagCount] = useState(0);

  const fetchBagCount = async () => {
    try {
      const res = await axios.get('http://localhost:4000/api/bag', {
        withCredentials: true
      });
      const totalQty = res.data.reduce((sum, item) => sum + item.quantity, 0);
      setBagCount(totalQty);
    } catch (err) {
      console.error("Error fetching bag count:", err);
      setBagCount(0); // fallback
    }
  };

  useEffect(() => {
    fetchBagCount(); // auto fetch on load
  }, []);

  return (
    <CartContext.Provider value={{ bagCount, fetchBagCount }}>
      {children}
    </CartContext.Provider>
  );
};
